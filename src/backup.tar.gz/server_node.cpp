#include <ros/ros.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "std_msgs/String.h"
#include <std_msgs/Float64.h> //메세지를 보내는 형태
#include <std_msgs/Float64MultiArray.h> //메세지를 보내는 형태

#define SERVERPORT 9000
#define BUFSIZE 512
#define SLAVEBUF 90
#define REBUFSIZE 9
#define SLAVEDATA 9
#define BUFHEAD 1

using namespace std;

char slave_x[REBUFSIZE] = "";
char X_A[BUFHEAD] = { 'A' };
char slave_y[REBUFSIZE] = "";
char Y_B[BUFHEAD] = { 'B' };
char slave_z[REBUFSIZE] = "";
char Z_C[BUFHEAD] = { 'C' };
char slave_xyz[SLAVEBUF] = "";
char slave_buf[SLAVEBUF] = "";

char CON_X[BUFHEAD] = { 'A' };
char CON_Y[BUFHEAD] = { 'B' };
char CON_Z[BUFHEAD] = { 'C' };
char TH_0[BUFHEAD] = { 'D' };
char TH_1[BUFHEAD] = { 'E' };
char TH_2[BUFHEAD] = { 'F' };
char TH_3[BUFHEAD] = { 'G' };
char TH_4[BUFHEAD] = { 'H' };
char TH_5[BUFHEAD] = { 'I' };

char slave_contact_x[REBUFSIZE] = "";
char slave_contact_y[REBUFSIZE] = "";
char slave_contact_z[REBUFSIZE] = "";
char slave_th_j0[REBUFSIZE] = "";
char slave_th_j1[REBUFSIZE] = "";
char slave_th_j2[REBUFSIZE] = "";
char slave_th_j3[REBUFSIZE] = "";
char slave_th_j4[REBUFSIZE] = "";
char slave_th_j5[REBUFSIZE] = "";
// std_msgs::String server_msg;
int cnt = 0;

void error(const char *msg) {
    perror(msg);
    exit(1);
}

// class Listener {
// private:
//     char topic_message[BUFSIZE] = { 0 };
// public:
//     void callback(const std_msgs::String::ConstPtr& msg);
//     char* getMessageValue();
// };
//
// void Listener::callback(const std_msgs::String::ConstPtr& msg) {
//     printf("fuck!!\n");
//     memset(topic_message, 0, BUFSIZE+1);
//     strcpy(topic_message, msg->data.c_str());
//     // ROS_INFO("I heard:[%s]\n", msg->data.c_str());
// }
//
// char* Listener::getMessageValue() {
//     return topic_message;
// }

class Listener {
private:
    double topic_message[6] = { 0 };
    // std_msgs::String server_msg;
public:
    void callback(const std_msgs::Float64MultiArray &msg);
    // char* getMessageValue();
};

void Listener::callback(const std_msgs::Float64MultiArray &msg) {
    memset(topic_message, 0, SLAVEDATA+1);
    // strcpy(topic_message, msg->data.c_str());
    // strcpy(slave_buf, topic_message);
    // ROS_INFO("I heard:[%s]", msg->data.c_str());
    memset(slave_xyz, 0, BUFSIZE+1);
    // server_msg = msg;
    for(int i = 0; i < SLAVEDATA; i++) {
      topic_message[i] = msg.data[i];
    }
    sprintf(slave_contact_x, "%f", topic_message[0]);
    sprintf(slave_contact_y, "%f", topic_message[1]);
    sprintf(slave_contact_z, "%f", topic_message[2]);
    sprintf(slave_th_j0, "%f", topic_message[3]);
    sprintf(slave_th_j1, "%f", topic_message[4]);
    sprintf(slave_th_j2, "%f", topic_message[5]);
    sprintf(slave_th_j3, "%f", topic_message[6]);
    sprintf(slave_th_j4, "%f", topic_message[7]);
    sprintf(slave_th_j5, "%f", topic_message[8]);
    strncat(slave_xyz, CON_X, BUFHEAD);
    strncat(slave_xyz, slave_contact_x, REBUFSIZE);
    strncat(slave_xyz, CON_Y, BUFHEAD);
    strncat(slave_xyz, slave_contact_y, REBUFSIZE);
    strncat(slave_xyz, CON_Z, BUFHEAD);
    strncat(slave_xyz, slave_contact_z, REBUFSIZE);
    strncat(slave_xyz, TH_0, BUFHEAD);
    strncat(slave_xyz, slave_th_j0, REBUFSIZE);
    strncat(slave_xyz, TH_1, BUFHEAD);
    strncat(slave_xyz, slave_th_j1, REBUFSIZE);
    strncat(slave_xyz, TH_2, BUFHEAD);
    strncat(slave_xyz, slave_th_j2, REBUFSIZE);
    strncat(slave_xyz, TH_3, BUFHEAD);
    strncat(slave_xyz, slave_th_j3, REBUFSIZE);
    strncat(slave_xyz, TH_4, BUFHEAD);
    strncat(slave_xyz, slave_th_j4, REBUFSIZE);
    strncat(slave_xyz, TH_5, BUFHEAD);
    strncat(slave_xyz, slave_th_j5, REBUFSIZE);
    strncpy(slave_buf, slave_xyz, SLAVEBUF);
    // ROS_INFO("I heard:[%s]\n", slave_buf);
}

// char* Listener::getMessageValue() {
//     return topic_message;
// }

int main (int argc, char** argv)
{
  argc = 0;
  argv = NULL;
  int retval;
  Listener listener;
  ros::init(argc, argv, "server_node");
  ros::NodeHandle nh;
  ros::Publisher server_pub = nh.advertise<std_msgs::String>("/server_messages/", 1000);
  ros::Subscriber server_sub = nh.subscribe("slave_messages", 1, &Listener::callback, &listener);

  // Socket Create
  int server_socket;
  // int sockfd, newsockfd, portno; //Socket file descriptors and port number
  // server_socket = socket(AF_INET, SOCK_STREAM, 0); // TCP
  server_socket = socket(AF_INET, SOCK_DGRAM, 0); // UDP
  if (server_socket < 0){
    error("ERROR opening socket");
  }
  else {
    printf("socket create success\n");
  }

  // Readdressing
  // int enable = 1;
  // if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &enable, sizeof(int)) < 0)
  //     error("setsockopt(SO_REUSEADDR) failed");

  // Bind
  struct sockaddr_in serveraddr;
  memset(&serveraddr, 0, sizeof(serveraddr));
  serveraddr.sin_family = AF_INET;
  serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);
  serveraddr.sin_port = htons(SERVERPORT);
  retval = bind(server_socket, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
  if (retval < 0){
    error("ERROR binding failed");
  }
  else {
    printf("bind success!\n");
  }

  // Data communication
  struct sockaddr_in cliaddr;
  int cli_socket;
  int k = 0;
  socklen_t addrlen;
  char buf[BUFSIZE+1];
  char buf_read[BUFSIZE+1];
  std_msgs::String message;
  std::stringstream ss;

  char udpsend[20] = "hello! udp\n";

  // Listen
  // retval = listen(server_socket, SOMAXCONN);
  // if (retval < 0) {
  //   error("ERROR Listening failed");
  // }
  // else {
  //   printf("Listening success!\n");
  // }



  // bzero(buf, BUFSIZE+1);
  // retval = recvfrom(cli_socket, buf, BUFSIZE, 0, (struct sockaddr *)&cliaddr, &addrlen);
  // if (retval > 0) {
  //     printf("received UDP success : %s\n", buf);
  // }
  // retval = sendto(cli_socket, udpsend, sizeof(udpsend)+1, 0, (struct sockaddr *)&cliaddr, sizeof(cliaddr));


  while(ros::ok()) {
    // printf("while Success1\n");
    // accept
    // cli_socket = accept(server_socket, (struct sockaddr *)&cliaddr, &addrlen);
    // if (cli_socket < 0) {
    //   error("ERROR Accepting failed");
    // }
    // else {
    //   printf("Accept success!\n");
    //   printf("\n[TCP server] Client : IP Address = %s, PORT = %d\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
    // }
    // bzero(buf, BUFSIZE+1);
    // retval = recvfrom(cli_socket, buf, BUFSIZE, 0, (struct sockaddr *)&cliaddr, &addrlen);
    // if (retval > 0) {
    //     printf("received UDP success : %s\n", buf);
    // }
    // retval = sendto(cli_socket, udpsend, sizeof(udpsend)+1, 0, (struct sockaddr *)&cliaddr, sizeof(cliaddr));

    // printf("\n[TCP server] Client : IP Address = %s, PORT = %d\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));
    // while(while_ongoing) {
    // void callback();
    addrlen = sizeof(cliaddr);

    // printf("while Success\n");
    ss.str(std::string()); //Clear contents of string stream
    bzero(buf, BUFSIZE+1);
    retval = recvfrom(cli_socket, buf, BUFSIZE, 0, (struct sockaddr *)&cliaddr, &addrlen);
    // retval = read(cli_socket, buf, BUFSIZE);
    printf("recv success? retval = %d\n", retval);
		// if (retval < 0) {
		// 	printf("data receive failed!");
		// 	// break;
		// }
		// else if (retval == 0) {
		// 	printf("retval == 0\n");
		// 	// break;
		// }
    buf[retval] = '\0';
		// printf("[Master/%s:%d] %s\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port), buf);
    // printf("Here is the message: %s\n",buf);
    ss << buf;
    message.data = ss.str();
    // ROS_INFO("%s", message.data.c_str());
    server_pub.publish(message);

    // data write
    // if (cnt == 0) {
    sendto(cli_socket, slave_buf, SLAVEBUF, 0, (struct sockaddr *)&cliaddr, sizeof(cliaddr));
    // retval = write(cli_socket, slave_buf, SLAVEBUF);
    // if (retval < 0) {
		// 	printf("data send failed! %d\n",cnt);
		// }
		// else {
		// 	// printf("[Slave] %d byte send!\n", retval);
    //   printf("[Slave] %s\n", slave_buf);
    //   // cnt=0;
		// }
    // cnt++;
    // }
    // data read
    // if (cnt == 1) {
    // cnt = 0;
    // }
    // printf("slave data sibal! : [%s]\n", slave_buf);
    // printf("I heard:[%s]\n", slave_buf);
    // bzero(buf_read,BUFSIZE+1);
    // bzero(slave_buf, BUFSIZE);
    ros::spinOnce();

    // }
    // ros::spin();
    // connection Terminate
  }

  close(cli_socket);
  printf("[TCP server] client connect terminate : IP Address = %s, PORT = %d \n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port));

  // server Terminate
  close(server_socket);

  return 0;
}
